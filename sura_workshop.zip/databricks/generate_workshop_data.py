# Databricks notebook source
# MAGIC %md
# MAGIC # Workshop Data Generator — Seguros Sura Vibe Coding Workshop
# MAGIC
# MAGIC Generates 6 synthetic Sura-themed tables in `sura_workshop.gold`:
# MAGIC
# MAGIC - `dim_sucursales` — sucursales Sura por región de Colombia
# MAGIC - `dim_productos` — catálogo de productos Vida y Salud
# MAGIC - `fact_daily_premiums` — primas diarias recaudadas por sucursal
# MAGIC - `fact_claims_activity` — actividad de siniestros y reclamos
# MAGIC - `fact_campaigns` — campañas comerciales y promociones
# MAGIC - `fact_daily_kpis` — KPIs agregados por región
# MAGIC
# MAGIC Includes intentional data quality issues for the Governance track (~370 defects).
# MAGIC
# MAGIC **Idempotent** — safe to re-run. Uses `CREATE OR REPLACE TABLE`. Patch logic
# MAGIC (headcount outliers) is folded directly into the `dim_sucursales` block
# MAGIC so no separate patch notebook is needed.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuration

# COMMAND ----------

CATALOG = "sura_workshop"
SCHEMA = "gold"

# Region distribution (matches Sura Colombia footprint — main departamentos)
REGIONS = {
    "ANT": {"departamento": "Antioquia", "branches": 140, "cities": ["Medellín", "Envigado", "Itagüí", "Bello", "Sabaneta", "Rionegro", "Apartadó", "Turbo"]},
    "BOG": {"departamento": "Bogotá DC", "branches": 180, "cities": ["Bogotá Norte", "Bogotá Centro", "Bogotá Occidente", "Bogotá Sur", "Chapinero", "Usaquén", "Suba", "Kennedy"]},
    "VAL": {"departamento": "Valle del Cauca", "branches": 110, "cities": ["Cali", "Palmira", "Buenaventura", "Tuluá", "Cartago", "Buga"]},
    "ATL": {"departamento": "Atlántico", "branches": 70, "cities": ["Barranquilla", "Soledad", "Malambo", "Sabanalarga"]},
    "BOL": {"departamento": "Bolívar", "branches": 50, "cities": ["Cartagena", "Magangué", "Turbaco"]},
    "SAN": {"departamento": "Santander", "branches": 60, "cities": ["Bucaramanga", "Floridablanca", "Girón", "Piedecuesta", "Barrancabermeja"]},
    "CUN": {"departamento": "Cundinamarca", "branches": 50, "cities": ["Soacha", "Chía", "Zipaquirá", "Facatativá", "Girardot"]},
    "RIS": {"departamento": "Risaralda", "branches": 30, "cities": ["Pereira", "Dosquebradas", "Santa Rosa de Cabal"]},
    "CAL": {"departamento": "Caldas", "branches": 25, "cities": ["Manizales", "La Dorada", "Chinchiná"]},
    "NSA": {"departamento": "Norte de Santander", "branches": 35, "cities": ["Cúcuta", "Ocaña", "Pamplona", "Villa del Rosario"]},
}

BRANCH_TYPES = ["Sucursal", "Agencia", "Punto Asesor", "Centro de Servicio", "Aliado"]
PRODUCT_TIERS = ["Básico", "Plus", "Premium", "Élite"]
RAMOS = ["Vida", "Salud"]
PRODUCT_FAMILIES = [
    "Seguro de Vida", "Vida Grupo", "Renta Vitalicia", "Pensión",
    "Enfermedades Graves", "Educación", "Accidentes Personales",
    "Pólizas de Salud", "Salud para Dos", "Salud para Todos",
    "Salud a tu Alcance", "Plan Modular", "Plan Renta Diaria", "Exequias",
]
EVENT_TYPES = [
    "Hospitalización", "Consulta Médica", "Medicamentos",
    "Cirugía", "Urgencias", "Examen Diagnóstico",
    "Fallecimiento", "Invalidez", "Renta Diaria",
]
CHANNELS = ["Sucursal", "Asesor", "Web", "App", "Bancaseguros"]
DISCOUNT_TYPES = ["percentage", "bonus_meses", "fixed_amount", "beneficio_extra"]
CAMPAIGN_NAMES = [
    "Plan Modular Lanzamiento", "Salud para Dos Promo", "Vida Grupo Empresarial",
    "Renta Vitalicia Beneficio", "Educación Anticipado", "Bienestar SURA",
    "Exequias Familia", "Accidentes Personales 2x1", "Salud para Todos Inclusión",
    "Enfermedades Graves Protección", "Vida Mujer", "Pensión Anticipada",
    "Plan Renta Diaria Premium", "Mes del Padre Salud", "Aniversario SURA",
]

print(f"Target: {CATALOG}.{SCHEMA}")
print(f"Total regiones: {len(REGIONS)} | Total sucursales: {sum(r['branches'] for r in REGIONS.values())}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create Catalog & Schema

# COMMAND ----------

spark.sql(f"CREATE CATALOG IF NOT EXISTS {CATALOG}")
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {CATALOG}.{SCHEMA}")
print(f"✅ {CATALOG}.{SCHEMA} ready")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table 1: dim_sucursales
# MAGIC
# MAGIC Includes the patched headcount outliers (folded in from the legacy `patch_workshop_data.py`).

# COMMAND ----------

import pandas as pd
import numpy as np
from datetime import date, timedelta

np.random.seed(42)

rows = []
sucursal_id = 0

# Approximate lat/lon ranges per departamento (Colombia)
lat_ranges = {
    "ANT": (5.5, 8.5), "BOG": (4.45, 4.85), "VAL": (3.0, 5.0),
    "ATL": (10.5, 11.2), "BOL": (8.0, 11.0), "SAN": (6.0, 8.0),
    "CUN": (4.0, 5.6), "RIS": (4.6, 5.6), "CAL": (4.8, 5.7), "NSA": (7.0, 8.5),
}
lon_ranges = {
    "ANT": (-77.0, -74.5), "BOG": (-74.25, -73.95), "VAL": (-77.5, -75.5),
    "ATL": (-75.2, -74.6), "BOL": (-75.8, -73.5), "SAN": (-74.0, -72.5),
    "CUN": (-75.0, -73.5), "RIS": (-76.2, -75.4), "CAL": (-75.9, -74.8), "NSA": (-73.5, -72.3),
}

for region_code, info in REGIONS.items():
    for i in range(info["branches"]):
        sucursal_id += 1
        sid = f"SUC-{region_code}-{sucursal_id:04d}"
        city = np.random.choice(info["cities"])
        stype = np.random.choice(BRANCH_TYPES, p=[0.40, 0.20, 0.20, 0.10, 0.10])
        opened = date(2000, 1, 1) + timedelta(days=int(np.random.uniform(0, 365 * 25)))

        lat = np.random.uniform(*lat_ranges[region_code])
        lon = np.random.uniform(*lon_ranges[region_code])
        is_24h = np.random.random() < 0.10  # algunos centros de servicio 24h
        headcount = int(np.random.choice([3, 6, 10, 15, 20, 30, 45, 60], p=[0.10, 0.20, 0.25, 0.20, 0.12, 0.08, 0.04, 0.01]))

        rows.append({
            "sucursal_id": sid,
            "sucursal_name": f"Sura {city} #{i+1}",
            "region": region_code,
            "departamento": info["departamento"],
            "city": city,
            "tipo_sucursal": stype,
            "fecha_apertura": opened,
            "latitude": round(lat, 6),
            "longitude": round(lon, 6),
            "is_24h": is_24h,
            "headcount": headcount,
        })

df_sucursales = pd.DataFrame(rows)

# ── Inject DQ issues ──
# 15 rows with NULL region
null_idx = np.random.choice(len(df_sucursales), 15, replace=False)
df_sucursales.loc[null_idx, "region"] = None

# 8 rows with future fecha_apertura
future_idx = np.random.choice(len(df_sucursales), 8, replace=False)
df_sucursales.loc[future_idx, "fecha_apertura"] = pd.Timestamp("2027-09-15").date()

# 12 rows with lat/lon = 0.0, 0.0
zero_idx = np.random.choice(len(df_sucursales), 12, replace=False)
df_sucursales.loc[zero_idx, ["latitude", "longitude"]] = 0.0

# 5 duplicate sucursal_ids
dup_idx = np.random.choice(len(df_sucursales), 5, replace=False)
for idx in dup_idx:
    source_idx = np.random.choice([i for i in range(len(df_sucursales)) if i != idx])
    df_sucursales.loc[idx, "sucursal_id"] = df_sucursales.loc[source_idx, "sucursal_id"]

# 20 rows with inconsistent casing on tipo_sucursal
case_idx = np.random.choice(len(df_sucursales), 20, replace=False)
df_sucursales.loc[case_idx, "tipo_sucursal"] = df_sucursales.loc[case_idx, "tipo_sucursal"].str.lower()

# ── Patch fold-in: 8 headcount outliers (was patch_workshop_data.py) ──
outlier_values = [0, 0, -5, 600, 750, 999, 1200, -10]
np.random.seed(99)  # match the patch's seed for reproducibility
patch_idx = np.random.choice(len(df_sucursales), 8, replace=False)
for i, idx in enumerate(patch_idx):
    df_sucursales.loc[idx, "headcount"] = outlier_values[i]

print(f"dim_sucursales: {len(df_sucursales)} rows")
print(f"  DQ issues: 15 null regions, 8 future dates, 12 zero coords, 5 dup IDs, 20 inconsistent casing, 8 headcount outliers")

# Reset seed for downstream determinism
np.random.seed(42)

sdf = spark.createDataFrame(df_sucursales)
sdf.write.mode("overwrite").saveAsTable(f"{CATALOG}.{SCHEMA}.dim_sucursales")
print(f"✅ {CATALOG}.{SCHEMA}.dim_sucursales written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table 2: dim_productos

# COMMAND ----------

producto_rows = []
producto_id_counter = 0

# Product → ramo mapping (Vida vs Salud)
PRODUCT_RAMO = {
    "Seguro de Vida": "Vida", "Vida Grupo": "Vida", "Renta Vitalicia": "Vida",
    "Pensión": "Vida", "Enfermedades Graves": "Vida", "Educación": "Vida",
    "Accidentes Personales": "Vida", "Exequias": "Vida",
    "Pólizas de Salud": "Salud", "Salud para Dos": "Salud",
    "Salud para Todos": "Salud", "Salud a tu Alcance": "Salud",
    "Plan Modular": "Salud", "Plan Renta Diaria": "Salud",
}

for product in PRODUCT_FAMILIES:
    ramo = PRODUCT_RAMO[product]
    for tier in PRODUCT_TIERS:
        # Skip some realistic tier combos
        if product == "Exequias" and tier in ("Élite",):
            continue
        if product == "Vida Grupo" and tier in ("Básico",):
            continue
        if product == "Salud a tu Alcance" and tier in ("Élite",):
            continue

        producto_id_counter += 1
        pid = f"PROD-{producto_id_counter:04d}"
        # Premiums in COP — annual base
        prima_anual = {
            "Básico":   float(np.random.choice([240000, 360000, 480000])),
            "Plus":     float(np.random.choice([720000, 960000, 1200000])),
            "Premium":  float(np.random.choice([1800000, 2400000, 3000000])),
            "Élite":    float(np.random.choice([4800000, 6000000, 8400000])),
        }[tier]
        cobertura_min = {"Básico": 5_000_000, "Plus": 20_000_000, "Premium": 80_000_000, "Élite": 250_000_000}[tier]
        cobertura_max = cobertura_min * 4
        launch_year = int(np.random.choice([2010, 2014, 2018, 2020, 2022, 2024]))

        producto_rows.append({
            "producto_id": pid,
            "producto_familia": product,
            "ramo": ramo,
            "tier": tier,
            "prima_anual_cop": prima_anual,
            "cobertura_min_cop": float(cobertura_min),
            "cobertura_max_cop": float(cobertura_max),
            "launch_year": launch_year,
            "is_active": np.random.random() > 0.05,
        })

df_productos = pd.DataFrame(producto_rows)

# ── Inject DQ issues ──
# 4 rows with negative prima_anual
neg_fee_idx = np.random.choice(len(df_productos), 4, replace=False)
df_productos.loc[neg_fee_idx, "prima_anual_cop"] = -10000.0

# 3 duplicate producto_ids
dup_prod_idx = np.random.choice(len(df_productos), 3, replace=False)
for idx in dup_prod_idx:
    source_idx = np.random.choice([i for i in range(len(df_productos)) if i != idx])
    df_productos.loc[idx, "producto_id"] = df_productos.loc[source_idx, "producto_id"]

# 5 rows with NULL tier
null_tier_idx = np.random.choice(len(df_productos), 5, replace=False)
df_productos.loc[null_tier_idx, "tier"] = None

print(f"dim_productos: {len(df_productos)} rows")
print(f"  DQ issues: 4 negative primas, 3 dup IDs, 5 null tiers")

sdf_productos = spark.createDataFrame(df_productos)
sdf_productos.write.mode("overwrite").saveAsTable(f"{CATALOG}.{SCHEMA}.dim_productos")
print(f"✅ {CATALOG}.{SCHEMA}.dim_productos written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table 3: fact_daily_premiums

# COMMAND ----------

# Get valid sucursal IDs (before DQ corruption) for FK generation
valid_sucursales = df_sucursales["sucursal_id"].dropna().unique().tolist()

date_range = pd.date_range("2024-01-01", "2026-04-13", freq="D")
all_premiums = []

for sid in valid_sucursales[:600]:  # cap at 600 to manage size
    region = df_sucursales[df_sucursales["sucursal_id"] == sid]["region"].iloc[0]
    if pd.isna(region):
        region = "BOG"

    # Base daily premium recaudo varies by region (in COP — Colombian pesos)
    base_amount = {
        "BOG": 380_000_000, "ANT": 320_000_000, "VAL": 240_000_000,
        "ATL": 180_000_000, "BOL": 130_000_000, "SAN": 170_000_000,
        "CUN": 120_000_000, "RIS": 90_000_000, "CAL": 80_000_000, "NSA": 95_000_000,
    }.get(region, 150_000_000)
    base_polizas = int(base_amount / 450_000)  # ~ COP 450k prima promedio mensual

    for d in date_range:
        # Weekly pattern: Monday/Tuesday peak (renovaciones), Sunday slow
        dow_mult = {0: 1.20, 1: 1.15, 2: 1.05, 3: 1.00, 4: 0.95, 5: 0.65, 6: 0.50}[d.dayofweek]

        # Monthly seasonality: Dec peak (renovaciones fin de año + aguinaldo), Mar dip,
        # Mayo/Junio ligero (mes del padre/madre — campañas), Sep/Oct back-to-school salud
        month_mult = {1: 0.90, 2: 0.95, 3: 0.85, 4: 1.00, 5: 1.10, 6: 1.05,
                      7: 1.00, 8: 1.05, 9: 1.10, 10: 1.05, 11: 1.10, 12: 1.45}[d.month]

        # Quincena effect — días 15 y último del mes (cobro de prima)
        is_payday = d.day == 15 or d.day == d.days_in_month
        payday_mult = 1.30 if is_payday else 1.0

        # YoY growth ~6% (seguros en Colombia crecen)
        years_from_start = (d - pd.Timestamp("2024-01-01")).days / 365
        growth = 1 + 0.06 * years_from_start

        noise = np.random.normal(1.0, 0.10)

        amount = base_amount * dow_mult * month_mult * payday_mult * growth * noise
        polizas = int(base_polizas * dow_mult * month_mult * payday_mult * growth * np.random.normal(1.0, 0.07))
        polizas = max(polizas, 5)
        prima_promedio = round(amount / max(polizas, 1), 2)

        # Channel mix (sums to 1.0 with mild noise)
        ch_sucursal = round(np.random.uniform(0.15, 0.30), 3)
        ch_asesor = round(np.random.uniform(0.25, 0.45), 3)
        ch_web = round(np.random.uniform(0.05, 0.15), 3)
        ch_app = round(np.random.uniform(0.08, 0.18), 3)
        ch_bancaseguros = round(1.0 - ch_sucursal - ch_asesor - ch_web - ch_app, 3)

        # Tipo de operación mix
        nuevas_pct = round(np.random.uniform(0.10, 0.25), 3)
        renovaciones_pct = round(np.random.uniform(0.45, 0.65), 3)
        modificaciones_pct = round(np.random.uniform(0.05, 0.15), 3)
        cancelaciones_pct = round(1.0 - nuevas_pct - renovaciones_pct - modificaciones_pct, 3)

        all_premiums.append({
            "fecha": d.date(),
            "sucursal_id": sid,
            "polizas_emitidas": polizas,
            "monto_prima_cop": round(amount, 2),
            "prima_promedio_cop": prima_promedio,
            "sucursal_pct": ch_sucursal,
            "asesor_pct": ch_asesor,
            "web_pct": ch_web,
            "app_pct": ch_app,
            "bancaseguros_pct": ch_bancaseguros,
            "nuevas_pct": nuevas_pct,
            "renovaciones_pct": renovaciones_pct,
            "modificaciones_pct": modificaciones_pct,
            "cancelaciones_pct": cancelaciones_pct,
        })

df_premiums = pd.DataFrame(all_premiums)

# ── Inject DQ issues ──
# 200 rows: amount = 0 but polizas > 0 (inconsistent — possibly aborted batch)
zero_amt_idx = np.random.choice(len(df_premiums), 200, replace=False)
df_premiums.loc[zero_amt_idx, "monto_prima_cop"] = 0.0

# 50 rows: negative prima_promedio
neg_ticket_idx = np.random.choice(len(df_premiums), 50, replace=False)
df_premiums.loc[neg_ticket_idx, "prima_promedio_cop"] = -1.0

# 30 rows: NULL fecha
null_date_idx = np.random.choice(len(df_premiums), 30, replace=False)
df_premiums.loc[null_date_idx, "fecha"] = None

# 40 rows: channel sums out of range (>1.05)
bad_channel_idx = np.random.choice(len(df_premiums), 40, replace=False)
df_premiums.loc[bad_channel_idx, "asesor_pct"] = df_premiums.loc[bad_channel_idx, "asesor_pct"] + 0.20

print(f"fact_daily_premiums: {len(df_premiums)} rows")
print(f"  DQ issues: 200 zero amount, 50 negative primas, 30 null dates, 40 bad channel mix")

sdf_premiums = spark.createDataFrame(df_premiums)
sdf_premiums.write.mode("overwrite").saveAsTable(f"{CATALOG}.{SCHEMA}.fact_daily_premiums")
print(f"✅ {CATALOG}.{SCHEMA}.fact_daily_premiums written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table 4: fact_claims_activity

# COMMAND ----------

valid_producto_ids = df_productos["producto_id"].dropna().unique().tolist()

n_asegurados = 5000
asegurado_ids = [f"ASG-{np.random.choice(list(REGIONS.keys()))}-{i:06d}" for i in range(1, n_asegurados + 1)]
poliza_ids = [f"POL-{i:08d}" for i in range(1, 8000)]
claim_dates = pd.date_range("2025-10-01", "2026-04-13", freq="D")

claims_rows = []
for _ in range(200000):
    asgid = np.random.choice(asegurado_ids)
    region_code = asgid.split("-")[1]
    sid = np.random.choice(valid_sucursales[:600])
    pid = np.random.choice(valid_producto_ids)
    polid = np.random.choice(poliza_ids)
    cd = pd.Timestamp(np.random.choice(claim_dates)).date()
    tier = np.random.choice(PRODUCT_TIERS, p=[0.40, 0.35, 0.20, 0.05])
    ramo = np.random.choice(RAMOS, p=[0.45, 0.55])

    # Claim amounts in COP — depend on event type
    event_type = np.random.choice(EVENT_TYPES, p=[0.18, 0.30, 0.20, 0.08, 0.10, 0.07, 0.02, 0.02, 0.03])
    base_event_amount = {
        "Hospitalización": 8_000_000, "Consulta Médica": 180_000, "Medicamentos": 350_000,
        "Cirugía": 25_000_000, "Urgencias": 1_200_000, "Examen Diagnóstico": 600_000,
        "Fallecimiento": 60_000_000, "Invalidez": 80_000_000, "Renta Diaria": 450_000,
    }[event_type]
    monto_reclamado = round(base_event_amount * np.random.uniform(0.5, 1.8), 2)
    monto_reservado = round(monto_reclamado * np.random.uniform(0.85, 1.05), 2)
    monto_pagado = round(monto_reclamado * np.random.uniform(0.6, 1.0), 2) if np.random.random() < 0.85 else 0.0

    estado = np.random.choice(["Aprobado", "En Revisión", "Rechazado", "Pagado"], p=[0.25, 0.20, 0.10, 0.45])
    canal = np.random.choice(CHANNELS, p=[0.20, 0.25, 0.15, 0.20, 0.20])

    claims_rows.append({
        "fecha_siniestro": cd,
        "asegurado_id": asgid,
        "poliza_id": polid,
        "producto_id": pid,
        "sucursal_id": sid,
        "region": region_code,
        "ramo": ramo,
        "tier_poliza": tier,
        "tipo_evento": event_type,
        "monto_reclamado_cop": monto_reclamado,
        "monto_reservado_cop": monto_reservado,
        "monto_pagado_cop": monto_pagado,
        "estado_siniestro": estado,
        "canal": canal,
    })

df_claims = pd.DataFrame(claims_rows)

# ── Inject DQ issues ──
# 100 rows: lowercase tier_poliza
tier_case_idx = np.random.choice(len(df_claims), 100, replace=False)
df_claims.loc[tier_case_idx, "tier_poliza"] = df_claims.loc[tier_case_idx, "tier_poliza"].str.lower()

# 40 rows: negative monto_pagado
neg_pago_idx = np.random.choice(len(df_claims), 40, replace=False)
df_claims.loc[neg_pago_idx, "monto_pagado_cop"] = -50000.0

# 25 rows: orphan region "XX"
orphan_idx = np.random.choice(len(df_claims), 25, replace=False)
df_claims.loc[orphan_idx, "region"] = "XX"
df_claims.loc[orphan_idx, "asegurado_id"] = "ASG-XX-000000"

# 80 rows: sucursal_id not in dim_sucursales (referential integrity break)
fake_sids = [f"SUC-ZZ-{9000+i:04d}" for i in range(80)]
ref_break_idx = np.random.choice(len(df_claims), 80, replace=False)
for i, idx in enumerate(ref_break_idx):
    df_claims.loc[idx, "sucursal_id"] = fake_sids[i]

print(f"fact_claims_activity: {len(df_claims)} rows")
print(f"  DQ issues: 100 lowercase tiers, 40 negative pagos, 25 orphan XX, 80 ref integrity breaks")

sdf_claims = spark.createDataFrame(df_claims)
sdf_claims.write.mode("overwrite").saveAsTable(f"{CATALOG}.{SCHEMA}.fact_claims_activity")
print(f"✅ {CATALOG}.{SCHEMA}.fact_claims_activity written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table 5: fact_campaigns

# COMMAND ----------

campaign_rows = []

for year in [2024, 2025, 2026]:
    n_promos = 60 if year < 2026 else 30
    for i in range(n_promos):
        start = date(year, 1, 1) + timedelta(days=int(np.random.uniform(0, 330 if year < 2026 else 100)))
        duration = int(np.random.uniform(7, 60))
        end = start + timedelta(days=duration)
        region = np.random.choice(list(REGIONS.keys()) + ["NACIONAL"], p=[0.07] * 10 + [0.30])
        dtype = np.random.choice(DISCOUNT_TYPES, p=[0.45, 0.20, 0.25, 0.10])
        dval = {
            "percentage": float(np.random.choice([0, 5, 10, 15, 20, 25, 30, 50])),
            "bonus_meses": float(np.random.choice([1, 2, 3, 6])),
            "fixed_amount": float(np.random.choice([50_000, 100_000, 250_000, 500_000])),
            "beneficio_extra": 0.0,
        }[dtype]
        target_tier = np.random.choice([None, "Élite", "Premium", "Plus", "Básico"], p=[0.5, 0.10, 0.15, 0.20, 0.05])
        target_ramo = np.random.choice([None, "Vida", "Salud"], p=[0.40, 0.30, 0.30])
        target_channel = np.random.choice([None, "App", "Web", "Asesor", "Sucursal"], p=[0.50, 0.15, 0.10, 0.20, 0.05])
        polizas_vendidas = int(np.random.uniform(200, 30000))
        budget = round(np.random.uniform(50_000_000, 2_500_000_000), 2) if np.random.random() < 0.85 else None

        campaign_rows.append({
            "campaign_id": f"CAMP-{year}-{i+1:03d}",
            "campaign_name": np.random.choice(CAMPAIGN_NAMES),
            "fecha_inicio": start,
            "fecha_fin": end,
            "region": region,
            "discount_type": dtype,
            "discount_value": dval,
            "target_tier": target_tier,
            "target_ramo": target_ramo,
            "target_channel": target_channel,
            "polizas_vendidas": polizas_vendidas,
            "presupuesto_cop": budget,
        })

df_campaigns = pd.DataFrame(campaign_rows)

# ── Inject DQ issues ──
# 3 promos: fecha_fin BEFORE fecha_inicio
bad_date_idx = np.random.choice(len(df_campaigns), 3, replace=False)
for idx in bad_date_idx:
    df_campaigns.loc[idx, "fecha_fin"] = df_campaigns.loc[idx, "fecha_inicio"] - timedelta(days=10)

# 5 promos: discount_value > 100 for percentage type (impossible)
pct_idx = df_campaigns[df_campaigns["discount_type"] == "percentage"].index
if len(pct_idx) >= 5:
    bad_pct_idx = np.random.choice(pct_idx, 5, replace=False)
    df_campaigns.loc[bad_pct_idx, "discount_value"] = 150.0

# 10 promos: NULL campaign_name
null_name_idx = np.random.choice(len(df_campaigns), 10, replace=False)
df_campaigns.loc[null_name_idx, "campaign_name"] = None

print(f"fact_campaigns: {len(df_campaigns)} rows")
print(f"  DQ issues: 3 inverted dates, 5 impossible discounts, 10 null names")

sdf_campaigns = spark.createDataFrame(df_campaigns)
sdf_campaigns.write.mode("overwrite").saveAsTable(f"{CATALOG}.{SCHEMA}.fact_campaigns")
print(f"✅ {CATALOG}.{SCHEMA}.fact_campaigns written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Table 6: fact_daily_kpis

# COMMAND ----------

# Pre-aggregate from fact_daily_premiums by region + date
kpi_rows = []
regions_list = list(REGIONS.keys())

for region_code in regions_list:
    region_sids = df_sucursales[df_sucursales["region"] == region_code]["sucursal_id"].tolist()
    n_sucursales = len(region_sids)

    for d in date_range:
        d_date = d.date()
        region_premiums = df_premiums[(df_premiums["sucursal_id"].isin(region_sids)) & (df_premiums["fecha"] == d_date)]

        if len(region_premiums) == 0:
            total_polizas = int(np.random.uniform(800, 8000))
            total_amount = round(total_polizas * np.random.uniform(300_000, 700_000), 2)
        else:
            total_polizas = int(region_premiums["polizas_emitidas"].sum())
            total_amount = round(region_premiums["monto_prima_cop"].sum(), 2)

        prima_promedio = round(total_amount / max(total_polizas, 1), 2)
        asegurados_activos = int(np.random.uniform(5000, 80000))
        nuevos_asegurados = int(np.random.uniform(50, 600))
        digital_pct = round(np.random.uniform(0.20, 0.45), 3)  # web + app share
        nps_proxy = round(np.random.normal(48, 12), 1)  # NPS-like score
        siniestralidad_pct = round(np.random.uniform(0.45, 0.78), 4)  # ratio siniestros / primas
        retencion_pct = round(np.random.uniform(0.82, 0.95), 4)

        # YoY growth (NULL for first year)
        yoy_growth = None
        if d.year >= 2025:
            yoy_growth = round(np.random.normal(0.06, 0.06), 4)

        kpi_rows.append({
            "kpi_date": d_date,
            "region": region_code,
            "total_sucursales": n_sucursales,
            "total_polizas": total_polizas,
            "total_prima_cop": total_amount,
            "prima_promedio_cop": prima_promedio,
            "asegurados_activos": asegurados_activos,
            "nuevos_asegurados": nuevos_asegurados,
            "digital_channel_pct": digital_pct,
            "nps_proxy": nps_proxy,
            "siniestralidad_pct": siniestralidad_pct,
            "retencion_pct": retencion_pct,
            "yoy_prima_growth": yoy_growth,
        })

df_kpis = pd.DataFrame(kpi_rows)

# ── Inject DQ issues ──
# 20 rows: polizas = 0 but amount > 0 (impossible)
zero_pol_idx = np.random.choice(len(df_kpis), 20, replace=False)
df_kpis.loc[zero_pol_idx, "total_polizas"] = 0

# 5 rows: region = "UNKNOWN"
unknown_idx = np.random.choice(len(df_kpis), 5, replace=False)
df_kpis.loc[unknown_idx, "region"] = "UNKNOWN"

# 3 rows: yoy_prima_growth = 999.99 (sentinel outlier)
non_null_yoy = df_kpis[df_kpis["yoy_prima_growth"].notna()].index
if len(non_null_yoy) >= 3:
    sentinel_idx = np.random.choice(non_null_yoy, 3, replace=False)
    df_kpis.loc[sentinel_idx, "yoy_prima_growth"] = 999.99

print(f"fact_daily_kpis: {len(df_kpis)} rows")
print(f"  DQ issues: 20 zero-polizas with amount, 5 UNKNOWN region, 3 sentinel outliers")

sdf_kpis = spark.createDataFrame(df_kpis)
sdf_kpis.write.mode("overwrite").saveAsTable(f"{CATALOG}.{SCHEMA}.fact_daily_kpis")
print(f"✅ {CATALOG}.{SCHEMA}.fact_daily_kpis written")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Validation Summary

# COMMAND ----------

print("=" * 70)
print("SEGUROS SURA — VIBE CODING WORKSHOP — DATA GENERATION SUMMARY")
print("=" * 70)

tables = [
    "dim_sucursales", "dim_productos", "fact_daily_premiums",
    "fact_claims_activity", "fact_campaigns", "fact_daily_kpis",
]
for t in tables:
    count = spark.sql(f"SELECT COUNT(*) as cnt FROM {CATALOG}.{SCHEMA}.{t}").collect()[0]["cnt"]
    print(f"  {CATALOG}.{SCHEMA}.{t}: {count:,} rows")

print()
print("DQ Issues Summary:")
print("  dim_sucursales:          15 null regions, 8 future dates, 12 zero coords, 5 dup IDs, 20 bad casing, 8 headcount outliers")
print("  dim_productos:           4 negative primas, 3 dup product IDs, 5 null tiers")
print("  fact_daily_premiums:     200 zero amount, 50 negative primas, 30 null dates, 40 bad channel mix")
print("  fact_claims_activity:    100 lowercase tiers, 40 negative pagos, 25 orphan XX, 80 ref breaks")
print("  fact_campaigns:          3 inverted dates, 5 impossible discounts, 10 null names")
print("  fact_daily_kpis:         20 zero-polizas with amount, 5 UNKNOWN region, 3 sentinel outliers")
print()
print("Total DQ defects: ~370 — Governance track has plenty to find!")

# Patch validation (mirrors the original patch_workshop_data.py output)
outliers = spark.sql(
    f"SELECT COUNT(*) AS cnt FROM {CATALOG}.{SCHEMA}.dim_sucursales "
    f"WHERE headcount < 1 OR headcount > 500"
).collect()[0]["cnt"]
print(f"  Headcount outliers (<1 or >500): {outliers} {'✅' if outliers >= 8 else '❌'}")

orphans = spark.sql(f"""
    SELECT COUNT(*) AS cnt FROM {CATALOG}.{SCHEMA}.fact_claims_activity m
    LEFT ANTI JOIN {CATALOG}.{SCHEMA}.dim_sucursales d ON m.sucursal_id = d.sucursal_id
""").collect()[0]["cnt"]
print(f"  Orphan sucursal_ids in fact_claims_activity: {orphans} {'✅' if orphans >= 70 else '❌'}")

nulls = spark.sql(
    f"SELECT COUNT(*) AS cnt FROM {CATALOG}.{SCHEMA}.dim_sucursales WHERE region IS NULL"
).collect()[0]["cnt"]
print(f"  Null regions in dim_sucursales: {nulls} {'✅' if nulls >= 10 else '❌'}")

print("=" * 70)
print("✅ Data generation complete. Workshop ready.")
