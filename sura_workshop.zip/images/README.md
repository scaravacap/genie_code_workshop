# Images for `slides.html`

The deck (`../slides.html`) references the following image files. The deck will render
without the optional ones, but with broken-image placeholders.

## Already in this folder

- `sura_logo.svg` — Seguros SURA logo (downloaded from sura.co — official azul variant).
- `sura_logo_white.svg` — alternate white variant (kept for use on dark backgrounds).
- `Databricks-Emblem.svg` — Databricks symbol (reused from `app/frontend/img/databricks-symbol.svg`).

## To add (copy from Marco Boniche's Arcos Dorados deck setup or sourced separately)

The slide deck reuses the same supporting illustrations as the Arcos Dorados / BAC
deck. Copy them from those `images/` folders — the slides expect the exact same filenames.

| Filename | Purpose | Where the deck uses it |
| --- | --- | --- |
| `attention_is_all_you_need.webp` | Transformer paper diagram (Vaswani et al., 2017) | Slide S04 — LLM fundamentals |
| `_agent_arch.webp` | Generic AI agent architecture diagram | Slide S05 — Agents |
| `kaparti.png` | Andrej Karpathy headshot | Slide S11 — Vibe Coding origins |
| `uncle_bob.png` | Robert C. Martin headshot | Slide S11b — Evolution of programming |
| `mcp_diagram.png` | Anthropic Model Context Protocol diagram | Slide S16 — MCP |
| `genie_code_slide_7_update.png` | Genie Code product overview screenshot | Slide S03 — Genie Code overview |
| `qr_saul.png` | LinkedIn QR for Saul Caravaca | Title slide presenter card |

The fastest path: copy these files from `images/` of the Arcos Dorados deck delivered
by Marco — the deck uses the exact same filenames so a `cp` is enough.
